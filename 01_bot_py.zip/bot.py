# bot.py
print("Quran Bot ana dosya")